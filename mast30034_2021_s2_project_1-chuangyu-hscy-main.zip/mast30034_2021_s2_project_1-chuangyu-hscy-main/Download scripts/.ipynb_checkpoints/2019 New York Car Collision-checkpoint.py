from google_drive_downloader import GoogleDriveDownloader as gdd

gdd.download_file_from_google_drive(file_id='1oKn4itNKrTpxkbS0F0bblboxuTehwnJ5',
                                    dest_path='./Data/2019 car collision/collision.csv',
                                    unzip=True)